import 'package:flutter/material.dart';
import 'package:camera/camera.dart';

class CameraHome extends StatefulWidget {
  CameraHome({Key? key}) : super(key: key);


  @override
  _CameraHomeState createState() => _CameraHomeState();
}

class _CameraHomeState extends State<CameraHome> {


  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
