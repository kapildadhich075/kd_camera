package com.example.kd_camera

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
